#include <Arduino.h>
#include <Wire.h>
#include <SoftwareSerial.h>

#include "LiquidCrystal_I2C.h"

double angle_rad = PI/180.0;
double angle_deg = 180.0/PI;
LiquidCrystal_I2C LCD_I2C_0x27(0x27, 16, 2);
SoftwareSerial btKontrol(8,9);
char karakterVeri;
#define M2_PIN1 6
#define M2_PIN2 7
#define M2_HIZ_PIN 5
void L298NMotorKontrol(int pin1, int pin2, int hizPin, bool yon, int hiz) {
     digitalWrite(pin1, yon);
    digitalWrite(pin2, !yon);
    analogWrite(hizPin, hiz);
}
#define M1_PIN1 2
#define M1_PIN2 4
#define M1_HIZ_PIN 3

void setup(){
    LCD_I2C_0x27.init();
    LCD_I2C_0x27.backlight();
    btKontrol.begin(9600);
    pinMode(M2_PIN1, OUTPUT);
    pinMode(M2_PIN2, OUTPUT);
    pinMode(M2_HIZ_PIN, OUTPUT);
    pinMode(M1_PIN1, OUTPUT);
    pinMode(M1_PIN2, OUTPUT);
    pinMode(M1_HIZ_PIN, OUTPUT);
    pinMode(13,OUTPUT);
    pinMode(12,OUTPUT);
}

void loop(){
    if(btKontrol.available()){
        karakterVeri=btKontrol.read();
    }
    if(((karakterVeri)==('F'))){
        L298NMotorKontrol(M2_PIN1, M2_PIN2, M2_HIZ_PIN, 1, 100);
        L298NMotorKontrol(M1_PIN1, M1_PIN2, M1_HIZ_PIN, 1, 100);
        LCD_I2C_0x27.setCursor(1 - 1, 1 - 1);
        LCD_I2C_0x27.print("Omer Ayaz");
        LCD_I2C_0x27.setCursor(1 - 1, 2 - 1);
        LCD_I2C_0x27.print("ADANALI geliyor");
    }
    if(((karakterVeri)==('B'))){
        L298NMotorKontrol(M2_PIN1, M2_PIN2, M2_HIZ_PIN, 0, 100);
        L298NMotorKontrol(M1_PIN1, M1_PIN2, M1_HIZ_PIN, 0, 100);
        LCD_I2C_0x27.setCursor(1 - 1, 1 - 1);
        LCD_I2C_0x27.print("Annesinin GULU");
        LCD_I2C_0x27.setCursor(1 - 1, 2 - 1);
        LCD_I2C_0x27.print("Geri Gidiyor");
    }
    if(((karakterVeri)==('R'))){
        L298NMotorKontrol(M2_PIN1, M2_PIN2, M2_HIZ_PIN, 0, 100);
        L298NMotorKontrol(M1_PIN1, M1_PIN2, M1_HIZ_PIN, 1, 100);
        LCD_I2C_0x27.setCursor(1 - 1, 1 - 1);
        LCD_I2C_0x27.print("Cekilin Yoldan");
        LCD_I2C_0x27.setCursor(1 - 1, 2 - 1);
        LCD_I2C_0x27.print("Sola Donuyor");
    }
    if(((karakterVeri)==('L'))){
        L298NMotorKontrol(M2_PIN1, M2_PIN2, M2_HIZ_PIN, 1, 100);
        L298NMotorKontrol(M1_PIN1, M1_PIN2, M1_HIZ_PIN, 0, 100);
        LCD_I2C_0x27.setCursor(1 - 1, 1 - 1);
        LCD_I2C_0x27.print("Korkun Benden");
        LCD_I2C_0x27.setCursor(1 - 1, 2 - 1);
        LCD_I2C_0x27.print("Saga Donuyor");
    }
    if(((karakterVeri)==('H'))){
        L298NMotorKontrol(M2_PIN1, M2_PIN2, M2_HIZ_PIN, 0, 100);
        L298NMotorKontrol(M1_PIN1, M1_PIN2, M1_HIZ_PIN, 0, 50);
    }
    if(((karakterVeri)==('G'))){
        L298NMotorKontrol(M2_PIN1, M2_PIN2, M2_HIZ_PIN, 1, 100);
        L298NMotorKontrol(M1_PIN1, M1_PIN2, M1_HIZ_PIN, 1, 50);
        LCD_I2C_0x27.setCursor(1 - 1, 1 - 1);
        LCD_I2C_0x27.print("Omer Ayaz");
        LCD_I2C_0x27.setCursor(1 - 1, 2 - 1);
        LCD_I2C_0x27.print("Gaza Basiyor");
    }
    if(((karakterVeri)==('I'))){
        L298NMotorKontrol(M2_PIN1, M2_PIN2, M2_HIZ_PIN, 1, 50);
        L298NMotorKontrol(M1_PIN1, M1_PIN2, M1_HIZ_PIN, 1, 100);
        LCD_I2C_0x27.setCursor(1 - 1, 1 - 1);
        LCD_I2C_0x27.print("WooooW");
        LCD_I2C_0x27.setCursor(1 - 1, 2 - 1);
        LCD_I2C_0x27.print("Kizlar Bana Hayran");
    }
    if(((karakterVeri)==('J'))){
        L298NMotorKontrol(M2_PIN1, M2_PIN2, M2_HIZ_PIN, 0, 50);
        L298NMotorKontrol(M1_PIN1, M1_PIN2, M1_HIZ_PIN, 0, 100);
    }
    if(((karakterVeri)==('S'))){
        LCD_I2C_0x27.clear();
        L298NMotorKontrol(M1_PIN1, M1_PIN2, M1_HIZ_PIN, 0, 0);
        L298NMotorKontrol(M2_PIN1, M2_PIN2, M2_HIZ_PIN, 0, 0);
    }
    if(((karakterVeri)==('W'))){
        digitalWrite(13,1);
    }
    if(((karakterVeri)==('w'))){
        digitalWrite(13,0);
    }
    if(((karakterVeri)==('U'))){
        digitalWrite(12,1);
    }
    if(((karakterVeri)==('u'))){
        digitalWrite(12,0);
    }
    _loop();
}

void _delay(float seconds){
    long endTime = millis() + seconds * 1000;
    while(millis() < endTime)_loop();
}

void _loop(){
}